import { Tag } from './tag.model';

describe('Tag', () => {
  it('should create an instance', () => {
    expect(new Tag()).toBeTruthy();
  });
});
