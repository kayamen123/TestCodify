export class Tag {
    title: string;

    constructor(input:any){
        this.title = input
    }
}