import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders,HttpParams} from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { catchError, retry } from 'rxjs/operators';


@Injectable({
  providedIn: 'root'
})
export class DummyServiceService {

  baseUrl = "https://dummyapi.io/data/api/";

  header = "60068fafe08dcb83ff19ea33"


  constructor(
    private http: HttpClient
  ) { }

  getAllPost(pages:number)  : Observable<any>{
    const params = new HttpParams()
    .set('limit', "10")
    .set('page', pages.toString())

    //set header with key
    let header = new HttpHeaders();
    header = header.set("app-id",this.header );
  
    return this.http
    .get(this.baseUrl + "post", { observe: 'response', headers: header, params: params })
    //Use local file to reduce api usage
    // .get("assets/postList.sample", { observe: 'response', headers: header, params: params })
  }
}
