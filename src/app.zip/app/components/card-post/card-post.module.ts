import { NgModule } from '@angular/core';
import { CommonModule, DatePipe } from '@angular/common';
import { MaterialModule } from 'src/app/material/material/material.module';
import { CardPostComponent } from './card-post.component';



@NgModule({
  declarations: [CardPostComponent],
  imports: [
    CommonModule,
    MaterialModule
  ],
  exports : [CardPostComponent],
  providers:[DatePipe],
})
export class CardPostModule { }
