import { DatePipe } from '@angular/common';
import { Component, Input, OnInit, Output , EventEmitter } from '@angular/core';
import { Router } from '@angular/router';
import { Post } from '../../models/post.model';
import { DummyServiceService } from '../../service/dummy-service.service';
import { Tag } from '../../models/tag.model'

@Component({
  selector: 'app-card-post',
  templateUrl: './card-post.component.html',
  styleUrls: ['./card-post.component.scss']
})
export class CardPostComponent implements OnInit {

  @Input('post') post!: Post;
  @Output() categoryClicked = new EventEmitter<string>();

  comments:Comment[] = []
  tags:Tag[] | undefined = [];
  publishDate:any;
  showComment:boolean=false;
  isLoadingComment:boolean=false;
  commentPage=0;


  constructor(public datepipe: DatePipe,private router: Router, private ds:DummyServiceService ) { }

  ngOnInit(): void {
    this.publishDate =this.datepipe.transform(this.post?.publishDate, 'medium');
    this.tags = this.post?.tags;
  }
  chooseCategory(category:string): void { this.categoryClicked.emit(category); }

  showUserProfile(id:string){

  }
  showComments(){

  }

}
