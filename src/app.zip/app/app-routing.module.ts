import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { HomeComponent } from './home/home.component';
import { PostComponent } from './post/post.component';
import { UserComponent } from './user/user.component';
import { UserListComponent } from './user/user-list/user-list.component';

const routes: Routes = [
  { path: '', redirectTo: 'home-component' , pathMatch: 'full'},
  { path: 'home-component', component: HomeComponent },
  { path: 'post-component', component: PostComponent },
  { path: 'user-component', component: UserComponent },
  { path: 'user-list-component', component: UserListComponent}
  
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { 

}
