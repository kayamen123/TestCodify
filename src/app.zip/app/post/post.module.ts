import { NgModule } from '@angular/core';
import { CommonModule, DatePipe } from '@angular/common';
import { MaterialModule } from '../material/material/material.module';
import { PostComponent } from './post.component';



@NgModule({
  declarations: [PostComponent],
  imports: [
    CommonModule,
    MaterialModule
  ],
  exports : [PostComponent],
  providers:[DatePipe],
})
export class PostModule { }
