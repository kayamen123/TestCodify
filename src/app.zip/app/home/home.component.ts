import { Component, HostListener, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Post } from '../models/post.model';
import { DummyServiceService } from '../service/dummy-service.service';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss']
})
export class HomeComponent implements OnInit {

  newList:Post[] = [];
  isRequestingData:boolean = true;
  category:string = "";
  prevCategory : string = "";
  pages=0;
  doneRequest:boolean = false;

  constructor(
    private route: ActivatedRoute,     
    private router: Router, 
    private DummyService:DummyServiceService
  ) { }

  ngOnInit(): void {
    this.route.queryParams.subscribe(
      (params) => {
        //check if there is change in category parameter
        this.category = params['category'];

        //if there is change, reset list
        if(this.prevCategory != this.category){
          this.newList = [];
          this.pages = 0;
          window.scroll(0,0);
          this.getPostList();
          console.log(this.newList);
        }else{
          this.prevCategory = this.category;
          this.getPostList();
          console.log(this.newList);
        }
      }
    )
  }
  @HostListener("window:scroll", ["$event"])
  onWindowScroll() {
    //In chrome and some browser scroll is given to body tag
    let post = (document.documentElement.scrollTop || document.body.scrollTop) + document.documentElement.offsetHeight;
    let max_page = document.documentElement.scrollHeight;

    // pos/max will give you the distance between scroll bottom and and bottom of screen in percentage.
    if(post == max_page || post > max_page-30 )   {
        //check if currently still requesting data, to prevent multiple request
      if(this.isRequestingData){

      }else{
        if( this.doneRequest){
          console.log(this.doneRequest);
        }else{
          this.getPostList();
          console.log(this.doneRequest);
          console.log(this.newList);
        }
      }

    }
  }

  getPostList(){
    if(this.doneRequest){

    }else{
      this.isRequestingData = true;
      this.DummyService.getAllPost(this.pages)// resp is of type `HttpResponse<Config>`
      .subscribe(resp => {
        const body = { ... resp.body };
        let postList = body.data;
        console.log(postList);
        if(postList.length < 1){
          this.doneRequest=true;
        }else{
          postList.forEach((element: any) => {
            let stat = new Post().deserialize(element);
            this.newList.push(stat);
            });
        }
        console.log(this.newList);
        console.log(this.doneRequest);
        this.pages++;
        this.isRequestingData = false;
      });
    }
  }

  onCategoryClicked($event:string){
    this.category = $event;
    this.newList = [];
    this.pages = 0;
    window.scroll(0,0);
    this.doneRequest=false;
    this.getPostList();
}
}
